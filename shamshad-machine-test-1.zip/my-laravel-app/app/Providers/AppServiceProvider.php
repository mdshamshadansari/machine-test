<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Interface\PaymentInterface;
use App\Services\Paypal;
use App\Services\Stripe;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind(PaymentInterface::class, Paypal::class);
       // $this->app->bind(PaymentInterface::class, Stripe::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
