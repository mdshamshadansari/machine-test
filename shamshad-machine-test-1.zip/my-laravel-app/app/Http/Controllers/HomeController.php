<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


class HomeController extends Controller
{
    public static function index() {
        try {
            return view('payment');
        } catch (\Throwable $th) {
            //throw $th;
        }
    }

    public static function payment(PaymentInterface $gateway, Request $request) {
    
        $validatedData = $request->validate([
            'amount' => 'required|numeric|min:1,max:999.99',
            'discount' => 'required|numeric|min:0, max:amount',
            'tax' => 'required|numeric|min:1, max:99.99'
        ], [
            'amount.required' => 'Amount field is required.',
            'discount.required' => 'Discount field is required.',
            'tax.required' => 'Tax field is required.',
            'amount.numeric' => 'Please enter numbers upto two decimal',
            'discount.numeric' => 'Please enter numbers upto two decimal',
            'tax.numeric' => 'Please enter numbers upto two decimal'    
        ]);

        try {

            $input = $request->all();

            $result=  $gateway->charge($input);
            
            return view('payment', compact('result'));
        } catch (\Exception $e) {

            \Log::error('Unexpected error: ' . $e->getMessage());
            return response()->json(['error' => 'An unexpected error occurred'], 500);
        }
    }
}
