<?php

namespace App\Services;

use App\Interface\PaymentInterface;

class Stripe implements PaymentInterface {
     public function charge($input) {
        return  $result = ($input['amount'] * $input['tax'])/100 - $input['discount'];
    }
}