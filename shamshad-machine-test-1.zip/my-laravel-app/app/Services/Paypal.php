<?php

namespace App\Services;

use App\Interface\PaymentInterface;

class Paypal implements PaymentInterface {

    public function charge($input) {
        return  $result = ($input['amount'] - $input['discount']) * ($input['tax']/100);
    }

}