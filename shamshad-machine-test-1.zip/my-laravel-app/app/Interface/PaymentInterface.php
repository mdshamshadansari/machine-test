<?php

namespace App\Interface;

interface PaymentInterface
{
    public function charge(int $amount);
}