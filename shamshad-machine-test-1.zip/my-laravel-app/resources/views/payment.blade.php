<!DOCTYPE html>
<html>
<head>
    <title>Laravel Developer Interview</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
</head>
<body>
<div class="container">
  
    <div class="card mt-5">
        <h3 class="card-header p-3">Laravel Developer Interview</h3>
        <div class="card-body">
            @session('success')
                <div class="alert alert-success" role="alert"> 
                    {{ $value }}
                </div>
            @endsession

             
            <form method="POST" action="{{ route('payment.pay') }}">
            
                @csrf
            
                <div class="mb-3">
                    <label class="form-label" for="inputName">Amount:</label>
                    <input 
                        type="number" 
                        name="amount" 
                        id="inputAmount"
                        class="form-control @error('amount') is-invalid @enderror" 
                        placeholder="Enter Amount">
                    <div id="amountError" class="text-danger"></div>
      
                    <!-- Way 2: Display Error Message -->
                    @error('amount')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>

                <div class="mb-3">
                    <label class="form-label" for="inputName">Discount:</label>
                    <input 
                        type="number" 
                        name="discount" 
                        id="inputDiscount"
                        class="form-control @error('discount') is-invalid @enderror" 
                        placeholder="Enter Discount">
                    <div id="discounttError" class="text-danger"></div>
                    <!-- Way 2: Display Error Message -->
                    @error('discount')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
           
                <div class="mb-3">
                    <label class="form-label" for="inputName">Tax(%):</label>
                    <input 
                        type="number" 
                        name="tax" 
                        id="inpuTax"
                        class="form-control @error('tax') is-invalid @enderror" 
                        placeholder="Enter Tax">
                    <div id="taxError" class="text-danger"></div>
                    <!-- Way 2: Display Error Message -->
                    @error('tax')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>  
           
                <div class="mb-3">
                    <button class="btn btn-primary btn-submit" id="submitBtn"> Pay</button>
                    <button class="btn btn-danger" id="resetButton"> Reset</button>

                </div>

                
            </form>
            @if(!empty($result))
                <span class="text-success">{{ $result }}</span>
            @endif
        </div>
    </div>       
          
</div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.19.5/jquery.validate.min.js"></script>
<script>
    $("#resetButton").on('click', function(){
        $("#inputAmount").val('');
        $("#inputDiscount").val('');
        $("#inpuTax").val('');
    });

    $("#submitBtn").on('click', function(){
        let amount = $("#inputAmount").val();
        let discount = $("#inputDiscount").val();
        let tax = $("#inpuTax").val();

        if(amount == ''){
            $("#amountError").val('Please enter amount')
        }
        if(discount == ''){
            $("#amountError").val('Please enter amount')
        }
        if(tax == ''){
            $("#amountError").val('Please enter amount')
        }


    })

</script>
</html>