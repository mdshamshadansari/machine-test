<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/payment', [HomeController::class, 'index'])->name('payment.page');
Route::post('/pay', [HomeController::class, 'payment'])->name('payment.pay');
