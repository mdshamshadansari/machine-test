<!DOCTYPE html>
<html>
<head>
    <title>Laravel Developer Interview</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
</head>
<body>
<div class="container">
  
    <div class="card mt-5">
        <h3 class="card-header p-3">Laravel Developer Interview</h3>
        <div class="card-body">
            <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-success" role="alert"> 
                    <?php echo e($value); ?>

                </div>
            <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

             
            <form method="POST" action="<?php echo e(route('payment.pay')); ?>">
            
                <?php echo csrf_field(); ?>
            
                <div class="mb-3">
                    <label class="form-label" for="inputName">Amount:</label>
                    <input 
                        type="number" 
                        name="amount" 
                        id="inputAmount"
                        class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        placeholder="Enter Amount">
                    <div id="amountError" class="text-danger"></div>
      
                    <!-- Way 2: Display Error Message -->
                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <label class="form-label" for="inputName">Discount:</label>
                    <input 
                        type="number" 
                        name="discount" 
                        id="inputDiscount"
                        class="form-control <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        placeholder="Enter Discount">
                    <div id="discounttError" class="text-danger"></div>
                    <!-- Way 2: Display Error Message -->
                    <?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
           
                <div class="mb-3">
                    <label class="form-label" for="inputName">Tax(%):</label>
                    <input 
                        type="number" 
                        name="tax" 
                        id="inpuTax"
                        class="form-control <?php $__errorArgs = ['tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                        placeholder="Enter Tax">
                    <div id="taxError" class="text-danger"></div>
                    <!-- Way 2: Display Error Message -->
                    <?php $__errorArgs = ['tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>  
           
                <div class="mb-3">
                    <button class="btn btn-primary btn-submit" id="submitBtn"> Pay</button>
                    <button class="btn btn-danger" id="resetButton"> Reset</button>

                </div>

                
            </form>
            <?php if(!empty($result)): ?>
                <span class="text-success"><?php echo e($result); ?></span>
            <?php endif; ?>
        </div>
    </div>       
          
</div>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.19.5/jquery.validate.min.js"></script>
<script>
    $("#resetButton").on('click', function(){
        $("#inputAmount").val('');
        $("#inputDiscount").val('');
        $("#inpuTax").val('');
    });

    $("#submitBtn").on('click', function(){
        let amount = $("#inputAmount").val();
        let discount = $("#inputDiscount").val();
        let tax = $("#inpuTax").val();

        if(amount == ''){
            $("#amountError").val('Please enter amount')
        }
        if(discount == ''){
            $("#amountError").val('Please enter amount')
        }
        if(tax == ''){
            $("#amountError").val('Please enter amount')
        }


    })

</script>
</html><?php /**PATH C:\Users\Sundew\my-laravel-app\resources\views/payment.blade.php ENDPATH**/ ?>